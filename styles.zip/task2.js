// API Base URL
const API_BASE_URL = 'https://api.magicthegathering.io/v1/cards';

// DOM Elements
const cardsContainer = document.getElementById('cards-container');
const cardDetails = document.getElementById('card-details');
const cardDetailsContent = document.getElementById('card-details-content');
const deckItems = document.getElementById('deck-items');
const deckCount = document.getElementById('deckCount');

// State for the Deck
const deck = [];

async function fetchCards() {
    try {
        const response = await fetch(`${API_BASE_URL}?pageSize=10`);
        const data = await response.json();
        displayCards(data.cards);
    } catch (error) {
        console.error('Error fetching:', error);
    }
}

// Display Cards in the Card List Section
function displayCards(cards) {
    cardsContainer.innerHTML = '';
    cards.forEach((card) => {
        const cardElement = document.createElement('div');
        cardElement.className = 'card cursor-pointer border rounded-lg p-4 text-center bg-gray-200 hover:bg-gray-300';
        cardElement.innerHTML = `
            <img src="${card.imageUrl || 'https://via.placeholder.com/150'}" alt="${card.name}" class="w-full h-48 object-cover rounded-lg mb-2 hover:scale-105 transition-all duration-300">
            <p class="font-semibold">${card.name}</p>
        `;
        cardElement.addEventListener('click', () => showCardDetails(card));
        cardsContainer.appendChild(cardElement);
    });
}

// Show Card Details
function showCardDetails(card) {
    cardDetailsContent.innerHTML = `
        <h3 class="text-2xl font-bold mb-4">${card.name}</h3>
        <img src="${card.imageUrl || 'https://via.placeholder.com/150'}" alt="${card.name}" class="w-full h-64 object-cover rounded-lg mb-4">
        <p><strong>Type:</strong> ${card.type}</p>
        <p><strong>Mana Cost:</strong> ${card.manaCost || 'N/A'}</p>
        <p><strong>Description:</strong> ${card.text || 'N/A'}</p>
        <button id="add-to-deck" class="mt-4 w-full bg-blue-600 text-white py-2 rounded-lg hover:bg-blue-700">Add to Deck</button>
    `;

    // Show card details modal
    cardDetails.classList.remove('hidden');

    // Add to Deck Button event listener
    document.getElementById('add-to-deck').addEventListener('click', () => addToDeck(card));
    document.getElementById('close-details').addEventListener('click', () => cardDetails.classList.add('hidden'));
}

// Add Card to Deck
function addToDeck(card) {
    if (deck.find((c) => c.id === card.id)) {
        alert('Card is already in the deck.');
        return;
    }
    deck.push(card);
    updateDeckView();
}

// Update Deck View
function updateDeckView() {
    deckItems.innerHTML = '';
    deck.forEach((card, index) => {
        const listItem = document.createElement('li');
        listItem.className = 'flex justify-between items-center p-2 mb-2 bg-gray-100 rounded-lg';
        listItem.innerHTML = `
            <span class="text-lg">${card.name}</span>
            <button class="remove-card bg-red-600 text-white py-1 px-2 rounded-lg hover:bg-red-700" data-index="${index}">Remove</button>
        `;
        deckItems.appendChild(listItem);
    });

    // Update Deck Count
    deckCount.innerText = deck.length;

    // Add Event Listeners to Remove Buttons
    document.querySelectorAll('.remove-card').forEach((button) =>
        button.addEventListener('click', (event) => removeFromDeck(event.target.dataset.index))
    );
}

// Remove Card from Deck
function removeFromDeck(index) {
    deck.splice(index, 1);
    updateDeckView();
}

// Fetch Cards on Page Load
fetchCards();